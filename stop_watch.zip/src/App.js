import './App.css';
import Stopwatch from './Stopwatch';

function App() {
  return (
    <div className="App">
      <Stopwatch/>
    </div>
  );
}

export default App;
